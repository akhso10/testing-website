// DOM Content Loaded
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize all functionality
            initNavbar();
            initSlider();
            initCart();
            initProductFilters();
            initCheckout();
            initFAQ();
            initBackToTop();
            initPromoTimer();
            initSmoothScroll();
            initWhatsAppOrders();
            initScrollAnimations();
            initToppingsSelection();
            initMobileOptimizations();
            initProductQuickView();
            initWishlist();
            initProductComparison();
            initRecentlyViewed();
            initProductRecommendations();
            initStockNotifications();
            initOrderTracking();
            initLoyaltyProgram();
            initGiftCards();
            initProductReviews();
            initSocialSharing();
            initNewsletterSubscription();
        });

        // Navbar functionality
        function initNavbar() {
            const hamburger = document.getElementById('hamburger');
            const navMenu = document.getElementById('nav-menu');
            
            if (hamburger && navMenu) {
                hamburger.addEventListener('click', function() {
                    navMenu.classList.toggle('active');
                    hamburger.classList.toggle('active');
                });
            }
            
            // Close mobile menu when clicking on a link
            const navLinks = document.querySelectorAll('.nav-link');
            navLinks.forEach(link => {
                link.addEventListener('click', function() {
                    if (window.innerWidth <= 768) {
                        navMenu.classList.remove('active');
                        hamburger.classList.remove('active');
                    }
                });
            });
            
            // Close mobile menu when clicking outside
            document.addEventListener('click', function(e) {
                if (window.innerWidth <= 768) {
                    if (!navMenu.contains(e.target) && !hamburger.contains(e.target)) {
                        navMenu.classList.remove('active');
                        hamburger.classList.remove('active');
                    }
                }
            });
        }

        // Slider functionality with swipe support
        function initSlider() {
            const slider = document.getElementById('slider');
            const slides = document.querySelectorAll('.slide');
            const dots = document.querySelectorAll('.slider-dot');
            const prevBtn = document.getElementById('prev-slide');
            const nextBtn = document.getElementById('next-slide');
            let currentSlide = 0;
            
            if (!slider || slides.length === 0) return;
            
            function showSlide(index) {
                // Update active slide
                slides.forEach(slide => slide.classList.remove('active'));
                slides[index].classList.add('active');
                
                // Update active dot
                dots.forEach(dot => dot.classList.remove('active'));
                dots[index].classList.add('active');
                
                // Update background color based on slide
                const color = slides[index].getAttribute('data-color');
                updateHeroBackground(color);
                
                currentSlide = index;
            }
            
            function updateHeroBackground(color) {
                const heroBg = document.querySelector('.hero-bg');
                if (!heroBg) return;
                
                const colors = {
                    red: 'linear-gradient(135deg, #dc2626 0%, #7e22ce 100%)',
                    yellow: 'linear-gradient(135deg, #d97706 0%, #7e22ce 100%)',
                    green: 'linear-gradient(135deg, #059669 0%, #7e22ce 100%)',
                    purple: 'linear-gradient(135deg, #7c3aed 0%, #7e22ce 100%)',
                    orange: 'linear-gradient(135deg, #ea580c 0%, #7e22ce 100%)'
                };
                
                heroBg.style.background = colors[color] || colors.purple;
            }
            
            // Next slide
            function nextSlide() {
                let next = currentSlide + 1;
                if (next >= slides.length) next = 0;
                showSlide(next);
            }
            
            // Previous slide
            function prevSlide() {
                let prev = currentSlide - 1;
                if (prev < 0) prev = slides.length - 1;
                showSlide(prev);
            }
            
            // Auto slide
            let slideInterval = setInterval(nextSlide, 5000);
            
            // Button navigation
            if (prevBtn) prevBtn.addEventListener('click', () => {
                clearInterval(slideInterval);
                prevSlide();
                slideInterval = setInterval(nextSlide, 5000);
            });
            
            if (nextBtn) nextBtn.addEventListener('click', () => {
                clearInterval(slideInterval);
                nextSlide();
                slideInterval = setInterval(nextSlide, 5000);
            });
            
            // Dot navigation
            dots.forEach((dot, index) => {
                dot.addEventListener('click', () => {
                    clearInterval(slideInterval);
                    showSlide(index);
                    slideInterval = setInterval(nextSlide, 5000);
                });
            });
            
            // Touch swipe support
            let startX = 0;
            let endX = 0;
            
            slider.addEventListener('touchstart', (e) => {
                startX = e.touches[0].clientX;
            });
            
            slider.addEventListener('touchend', (e) => {
                endX = e.changedTouches[0].clientX;
                handleSwipe();
            });
            
            // Mouse swipe support
            slider.addEventListener('mousedown', (e) => {
                startX = e.clientX;
                document.addEventListener('mouseup', handleMouseUp);
            });
            
            function handleMouseUp(e) {
                endX = e.clientX;
                handleSwipe();
                document.removeEventListener('mouseup', handleMouseUp);
            }
            
            function handleSwipe() {
                const diff = startX - endX;
                const swipeThreshold = 50;
                
                if (Math.abs(diff) > swipeThreshold) {
                    clearInterval(slideInterval);
                    if (diff > 0) {
                        nextSlide();
                    } else {
                        prevSlide();
                    }
                    slideInterval = setInterval(nextSlide, 5000);
                }
            }
        }

        // Cart functionality
        function initCart() {
            const cartIcon = document.getElementById('cart-icon');
            const cartSidebar = document.getElementById('cart-sidebar');
            const cartOverlay = document.getElementById('cart-overlay');
            const closeCart = document.querySelector('.close-cart');
            const cartItems = document.getElementById('cart-items');
            const cartCount = document.querySelector('.cart-count');
            const cartNotification = document.getElementById('cart-notification');
            const addToCartButtons = document.querySelectorAll('.add-to-cart, .add-to-cart-btn');
            const continueShopping = document.querySelector('.continue-shopping');
            const checkoutBtn = document.getElementById('checkout-btn');
            const clearCartBtn = document.getElementById('clear-cart-btn');
            
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            
            // Toggle cart sidebar
            if (cartIcon && cartSidebar && cartOverlay) {
                cartIcon.addEventListener('click', () => {
                    cartSidebar.classList.add('active');
                    cartOverlay.classList.add('active');
                    document.body.style.overflow = 'hidden';
                });
            }
            
            function closeCartSidebar() {
                if (cartSidebar && cartOverlay) {
                    cartSidebar.classList.remove('active');
                    cartOverlay.classList.remove('active');
                    document.body.style.overflow = '';
                }
            }
            
            if (closeCart) {
                closeCart.addEventListener('click', closeCartSidebar);
            }
            
            if (cartOverlay) {
                cartOverlay.addEventListener('click', closeCartSidebar);
            }
            
            if (continueShopping) {
                continueShopping.addEventListener('click', closeCartSidebar);
            }
            
            // Clear cart functionality
            if (clearCartBtn) {
                clearCartBtn.addEventListener('click', function() {
                    if (cart.length === 0) {
                        alert('Keranjang belanja sudah kosong!');
                        return;
                    }
                    
                    if (confirm('Apakah Anda yakin ingin menghapus semua item dari keranjang?')) {
                        cart = [];
                        updateCart();
                        saveCartToStorage();
                        alert('Keranjang belanja berhasil dikosongkan!');
                    }
                });
            }
            
            // Add to cart functionality
            addToCartButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    const productId = this.getAttribute('data-id');
                    const productName = this.getAttribute('data-product');
                    const productPrice = parseInt(this.getAttribute('data-price'));
                    
                    // Check if product already in cart
                    const existingItem = cart.find(item => item.id === productId);
                    
                    if (existingItem) {
                        existingItem.quantity += 1;
                    } else {
                        cart.push({
                            id: productId,
                            name: productName,
                            price: productPrice,
                            quantity: 1
                        });
                    }
                    
                    updateCart();
                    saveCartToStorage();
                    showCartNotification();
                    animateCartIcon();
                });
            });
            
            // Checkout functionality
            if (checkoutBtn) {
                checkoutBtn.addEventListener('click', function() {
                    if (cart.length === 0) {
                        alert('Keranjang belanja kosong. Silakan tambahkan produk terlebih dahulu.');
                        return;
                    }
                    
                    closeCartSidebar();
                    openCheckoutModal();
                });
            }
            
            // Update cart
            function updateCart() {
                // Update cart count
                const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
                if (cartCount) {
                    cartCount.textContent = totalItems;
                }
                
                // Update checkout button state
                if (checkoutBtn) {
                    checkoutBtn.disabled = cart.length === 0;
                }
                
                // Update clear cart button state
                if (clearCartBtn) {
                    clearCartBtn.disabled = cart.length === 0;
                }
                
                // Update cart items
                if (cartItems) {
                    cartItems.innerHTML = '';
                    
                    if (cart.length === 0) {
                        cartItems.innerHTML = `
                            <div class="empty-cart">
                                <i class="fas fa-shopping-cart"></i>
                                <p>Keranjang belanja kosong</p>
                                <small>Tambahkan produk untuk mulai berbelanja</small>
                            </div>
                        `;
                    } else {
                        cart.forEach(item => {
                            const cartItem = document.createElement('div');
                            cartItem.className = 'cart-item';
                            cartItem.innerHTML = `
                                <div class="cart-item-info">
                                    <h4>${item.name}</h4>
                                    <p>Rp ${item.price.toLocaleString('id-ID')}</p>
                                </div>
                                <div class="cart-item-controls">
                                    <div class="quantity-controls">
                                        <button class="qty-btn decrease" data-id="${item.id}">-</button>
                                        <span class="qty-display">${item.quantity}</span>
                                        <button class="qty-btn increase" data-id="${item.id}">+</button>
                                    </div>
                                    <button class="remove-item" data-id="${item.id}">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            `;
                            cartItems.appendChild(cartItem);
                        });
                        
                        // Add event listeners to quantity buttons
                        document.querySelectorAll('.increase').forEach(button => {
                            button.addEventListener('click', function() {
                                const id = this.getAttribute('data-id');
                                const item = cart.find(item => item.id === id);
                                if (item) {
                                    item.quantity += 1;
                                    updateCart();
                                    saveCartToStorage();
                                }
                            });
                        });
                        
                        document.querySelectorAll('.decrease').forEach(button => {
                            button.addEventListener('click', function() {
                                const id = this.getAttribute('data-id');
                                const item = cart.find(item => item.id === id);
                                if (item && item.quantity > 1) {
                                    item.quantity -= 1;
                                    updateCart();
                                    saveCartToStorage();
                                }
                            });
                        });
                        
                        document.querySelectorAll('.remove-item').forEach(button => {
                            button.addEventListener('click', function() {
                                const id = this.getAttribute('data-id');
                                cart = cart.filter(item => item.id !== id);
                                updateCart();
                                saveCartToStorage();
                            });
                        });
                    }
                    
                    // Update cart summary
                    const subtotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
                    const total = subtotal;
                    
                    const cartSubtotal = document.getElementById('cart-subtotal');
                    const cartTotal = document.getElementById('cart-total');
                    
                    if (cartSubtotal) {
                        cartSubtotal.textContent = `Rp ${subtotal.toLocaleString('id-ID')}`;
                    }
                    
                    if (cartTotal) {
                        cartTotal.textContent = `Rp ${total.toLocaleString('id-ID')}`;
                    }
                }
            }
            
            // Save cart to localStorage
            function saveCartToStorage() {
                localStorage.setItem('cart', JSON.stringify(cart));
            }
            
            // Show cart notification
            function showCartNotification() {
                if (cartNotification) {
                    cartNotification.style.display = 'flex';
                    setTimeout(() => {
                        cartNotification.style.display = 'none';
                    }, 3000);
                }
            }
            
            // Animate cart icon
            function animateCartIcon() {
                if (cartIcon) {
                    cartIcon.classList.add('animate');
                    setTimeout(() => {
                        cartIcon.classList.remove('animate');
                    }, 600);
                }
            }
            
            // Initialize cart on page load
            updateCart();
            
            // Expose functions for checkout
            window.getCart = () => cart;
            window.clearCart = () => {
                cart = [];
                updateCart();
                saveCartToStorage();
            };
        }

        // Product filters
        function initProductFilters() {
            const filterButtons = document.querySelectorAll('.filter-btn');
            const productCards = document.querySelectorAll('.product-card');
            
            filterButtons.forEach(button => {
                button.addEventListener('click', function() {
                    // Remove active class from all buttons
                    filterButtons.forEach(btn => btn.classList.remove('active'));
                    // Add active class to clicked button
                    this.classList.add('active');
                    
                    const filter = this.getAttribute('data-filter');
                    
                    productCards.forEach(card => {
                        if (filter === 'all' || card.getAttribute('data-category') === filter) {
                            card.style.display = 'block';
                            // Add animation
                            card.style.animation = 'fadeInUp 0.5s ease forwards';
                        } else {
                            card.style.display = 'none';
                        }
                    });
                });
            });
            
            // Search functionality
            const searchInput = document.querySelector('.search-input');
            if (searchInput) {
                searchInput.addEventListener('input', function() {
                    const searchTerm = this.value.toLowerCase();
                    
                    productCards.forEach(card => {
                        const productName = card.querySelector('h3').textContent.toLowerCase();
                        
                        if (productName.includes(searchTerm)) {
                            card.style.display = 'block';
                        } else {
                            card.style.display = 'none';
                        }
                    });
                    
                    // Reset filter buttons
                    filterButtons.forEach(btn => btn.classList.remove('active'));
                    filterButtons[0].classList.add('active'); // Set "Semua" as active
                });
            }
        }

        // Checkout functionality
        function initCheckout() {
            const checkoutModal = document.getElementById('checkout-modal');
            const closeModal = document.querySelectorAll('.close-modal');
            const checkoutForm = document.getElementById('checkout-form');
            
            // Close modal buttons
            closeModal.forEach(button => {
                button.addEventListener('click', function() {
                    const modal = this.closest('.modal');
                    if (modal) {
                        modal.classList.remove('active');
                        document.body.style.overflow = '';
                    }
                });
            });
            
            // Close modal when clicking outside
            document.addEventListener('click', function(e) {
                if (e.target.classList.contains('modal')) {
                    e.target.classList.remove('active');
                    document.body.style.overflow = '';
                }
            });
            
            // Open checkout modal
            window.openCheckoutModal = function() {
                const cart = window.getCart();
                if (!cart || cart.length === 0) {
                    alert('Keranjang belanja kosong!');
                    return;
                }
                
                // Populate checkout items
                const checkoutItems = document.getElementById('checkout-items');
                const checkoutSummaryItems = document.getElementById('checkout-summary-items');
                
                if (checkoutItems) {
                    checkoutItems.innerHTML = '';
                    cart.forEach(item => {
                        const checkoutItem = document.createElement('div');
                        checkoutItem.className = 'checkout-item';
                        checkoutItem.innerHTML = `
                            <div class="checkout-item-info">
                                <h4>${item.name}</h4>
                                <p>Jumlah: ${item.quantity}</p>
                            </div>
                            <div class="checkout-item-price">
                                Rp ${(item.price * item.quantity).toLocaleString('id-ID')}
                            </div>
                        `;
                        checkoutItems.appendChild(checkoutItem);
                    });
                }
                
                // Update summary
                const subtotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
                const total = subtotal;
                
                const checkoutSubtotal = document.getElementById('checkout-subtotal');
                const checkoutTotal = document.getElementById('checkout-total');
                
                if (checkoutSubtotal) checkoutSubtotal.textContent = `Rp ${subtotal.toLocaleString('id-ID')}`;
                if (checkoutTotal) checkoutTotal.textContent = `Rp ${total.toLocaleString('id-ID')}`;
                
                // Show modal
                if (checkoutModal) {
                    checkoutModal.classList.add('active');
                    document.body.style.overflow = 'hidden';
                }
            };
            
            // Form submission
            if (checkoutForm) {
                checkoutForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const name = document.getElementById('customer-name').value.trim();
                    const phone = document.getElementById('customer-phone').value.trim();
                    const address = document.getElementById('customer-address').value.trim();
                    const paymentMethod = document.getElementById('payment-method').value;
                    const customToppings = document.getElementById('custom-toppings').value.trim();
                    const notes = document.getElementById('customer-notes').value.trim();
                    
                    if (!name || !phone || !address || !paymentMethod) {
                        alert('Mohon lengkapi semua data yang diperlukan!');
                        return;
                    }
                    
                    const cart = window.getCart();
                    
                    // Calculate totals
                    const subtotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
                    const total = subtotal;
                    
                    // Build order message
                    let message = `🛒 *PESANAN BARU MIX & CRUNCH*\n\n`;
                    message += `👤 *Data Pemesan:*\n`;
                    message += `Nama: ${name}\n`;
                    message += `WhatsApp: ${phone}\n`;
                    message += `Alamat: ${address}\n`;
                    message += `Metode Pembayaran: ${paymentMethod}\n\n`;
                    
                    message += `📦 *Detail Pesanan:*\n`;
                    cart.forEach((item, index) => {
                        message += `${index + 1}. ${item.name}\n`;
                        message += `   Jumlah: ${item.quantity}\n`;
                        message += `   Harga: Rp ${item.price.toLocaleString('id-ID')}\n`;
                        message += `   Subtotal: Rp ${(item.price * item.quantity).toLocaleString('id-ID')}\n\n`;
                    });
                    
                    if (customToppings) {
                        message += `🍽️ *Topping:*\n${customToppings}\n\n`;
                    }
                    
                    message += `💰 *Ringkasan Pembayaran:*\n`;
                    message += `Subtotal: Rp ${subtotal.toLocaleString('id-ID')}\n`;
                    message += `*Total: Rp ${total.toLocaleString('id-ID')}*\n\n`;
                    message += `*Catatan: Ongkos kirim akan diinformasikan setelah konfirmasi pesanan.*\n\n`;
                    
                    if (notes) {
                        message += `📝 *Catatan:*\n${notes}\n\n`;
                    }
                    
                    message += `Terima kasih telah memesan! 🙏`;
                    
                    // Encode message for WhatsApp
                    const encodedMessage = encodeURIComponent(message);
                    const whatsappURL = `https://wa.me/6285122013643?text=${encodedMessage}`;
                    
                    // Open WhatsApp
                    window.open(whatsappURL, '_blank');
                    
                    // Close modal and clear cart
                    checkoutModal.classList.remove('active');
                    document.body.style.overflow = '';
                    
                    // Clear cart after successful order
                    window.clearCart();
                    
                    // Reset form
                    this.reset();
                    
                    // Show success message
                    setTimeout(() => {
                        alert('Pesanan berhasil dikirim ke WhatsApp! Terima kasih telah berbelanja.');
                    }, 1000);
                });
            }
        }

        // WhatsApp direct orders
        function initWhatsAppOrders() {
            const whatsappButtons = document.querySelectorAll('.whatsapp-order-btn');
            
            whatsappButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    const productName = this.getAttribute('data-product');
                    const productPrice = parseInt(this.getAttribute('data-price'));
                    
                    // Build simple order message
                    let message = `🛒 *PESANAN LANGSUNG MIX & CRUNCH*\n\n`;
                    message += `Halo, saya ingin memesan:\n\n`;
                    message += `📦 Produk: ${productName}\n`;
                    message += `💰 Harga: Rp ${productPrice.toLocaleString('id-ID')}\n`;
                    message += `*Catatan: Ongkos kirim akan diinformasikan setelah konfirmasi pesanan.*\n\n`;
                    message += `Mohon konfirmasi ketersediaan dan proses pemesanan. Terima kasih! 🙏`;
                    
                    // Encode message for WhatsApp
                    const encodedMessage = encodeURIComponent(message);
                    const whatsappURL = `https://wa.me/6285122013643?text=${encodedMessage}`;
                    
                    // Open WhatsApp
                    window.open(whatsappURL, '_blank');
                });
            });
        }

        // Toppings selection functionality
        function initToppingsSelection() {
            const toppingItems = document.querySelectorAll('.topping-item');
            
            toppingItems.forEach(item => {
                item.addEventListener('click', function(e) {
                    if (e.target.type !== 'checkbox') {
                        const checkbox = this.querySelector('input[type="checkbox"]');
                        checkbox.checked = !checkbox.checked;
                    }
                    
                    this.classList.toggle('selected');
                });
            });
        }

        // FAQ functionality
        function initFAQ() {
            const faqItems = document.querySelectorAll('.faq-item');
            
            faqItems.forEach(item => {
                const question = item.querySelector('.faq-question');
                
                question.addEventListener('click', () => {
                    // Close all other FAQ items
                    faqItems.forEach(otherItem => {
                        if (otherItem !== item) {
                            otherItem.classList.remove('active');
                        }
                    });
                    
                    // Toggle current FAQ item
                    item.classList.toggle('active');
                });
            });
        }

        // Back to top button
        function initBackToTop() {
            const backToTop = document.getElementById('back-to-top');
            
            if (backToTop) {
                window.addEventListener('scroll', () => {
                    if (window.pageYOffset > 300) {
                        backToTop.classList.add('visible');
                    } else {
                        backToTop.classList.remove('visible');
                    }
                });
                
                backToTop.addEventListener('click', () => {
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                });
            }
        }

        // Promo timer
        function initPromoTimer() {
            function updatePromoTimer() {
                const now = new Date();
                const endOfDay = new Date();
                endOfDay.setHours(23, 59, 59, 999);
                
                const timeLeft = endOfDay - now;
                
                if (timeLeft <= 0) {
                    // Reset to next day
                    endOfDay.setDate(endOfDay.getDate() + 1);
                    endOfDay.setHours(23, 59, 59, 999);
                }
                
                const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
                const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
                
                const promoHours = document.getElementById('promo-hours');
                const promoMinutes = document.getElementById('promo-minutes');
                const promoSeconds = document.getElementById('promo-seconds');
                
                if (promoHours) promoHours.textContent = hours.toString().padStart(2, '0');
                if (promoMinutes) promoMinutes.textContent = minutes.toString().padStart(2, '0');
                if (promoSeconds) promoSeconds.textContent = seconds.toString().padStart(2, '0');
            }
            
            setInterval(updatePromoTimer, 1000);
            updatePromoTimer();
        }

        // Smooth scrolling for anchor links
        function initSmoothScroll() {
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    const targetId = this.getAttribute('href');
                    if (targetId === '#') return;
                    
                    const targetElement = document.querySelector(targetId);
                    if (targetElement) {
                        const offsetTop = targetElement.offsetTop - 80;
                        
                        window.scrollTo({
                            top: offsetTop,
                            behavior: 'smooth'
                        });
                    }
                });
            });
        }

        // Scroll animations
        function initScrollAnimations() {
            const animatedElements = document.querySelectorAll('.product-card, .testimonial-card, .section-header, .about-content');
            
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('bounce-in');
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.1 });
            
            animatedElements.forEach(el => {
                observer.observe(el);
            });
        }

        // Mobile optimizations
        function initMobileOptimizations() {
            // Reorder navbar elements for mobile
            if (window.innerWidth <= 768) {
                const navMenu = document.getElementById('nav-menu');
                const navSearch = document.querySelector('.nav-search');
                const navIcons = document.querySelector('.nav-icons');
                
                if (navMenu && navSearch && navIcons) {
                    // Move search to top
                    navMenu.insertBefore(navSearch, navMenu.firstChild);
                    
                    // Move cart to top right
                    const navContainer = document.querySelector('.nav-container');
                    if (navContainer) {
                        navContainer.insertBefore(navIcons, navContainer.children[1]);
                    }
                }
            }
        }

        // Product quick view
        function initProductQuickView() {
            // Implementation for quick view modal
            console.log('Product Quick View initialized');
        }

        // Wishlist functionality
        function initWishlist() {
            // Implementation for wishlist
            console.log('Wishlist initialized');
        }

        // Product comparison
        function initProductComparison() {
            // Implementation for product comparison
            console.log('Product Comparison initialized');
        }

        // Recently viewed products
        function initRecentlyViewed() {
            // Implementation for recently viewed products
            console.log('Recently Viewed initialized');
        }

        // Product recommendations
        function initProductRecommendations() {
            // Implementation for product recommendations
            console.log('Product Recommendations initialized');
        }

        // Stock notifications
        function initStockNotifications() {
            // Implementation for stock notifications
            console.log('Stock Notifications initialized');
        }

        // Order tracking
        function initOrderTracking() {
            // Implementation for order tracking
            console.log('Order Tracking initialized');
        }

        // Loyalty program
        function initLoyaltyProgram() {
            // Implementation for loyalty program
            console.log('Loyalty Program initialized');
        }

        // Gift cards
        function initGiftCards() {
            // Implementation for gift cards
            console.log('Gift Cards initialized');
        }

        // Product reviews
        function initProductReviews() {
            // Implementation for product reviews
            console.log('Product Reviews initialized');
        }

        // Social sharing
        function initSocialSharing() {
            // Implementation for social sharing
            console.log('Social Sharing initialized');
        }

        // Newsletter subscription
        function initNewsletterSubscription() {
            // Implementation for newsletter subscription
            console.log('Newsletter Subscription initialized');
        }